//
//  ViewController.swift
//  RadiobtnActionDemp
//
//  Created by Jivesh Soni on 21/03/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblfemale: UILabel!
    @IBOutlet weak var malelbl: UILabel!
    @IBOutlet weak var btnfemale: UIButton!
    @IBOutlet weak var malebtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        malebtn.setImage(UIImage.init(named: "Unchecksquare"), for: .normal)
        malebtn.setImage(UIImage.init(named: "checksquare"), for: .selected)
    
        btnfemale.setImage(UIImage.init(named: "Unchecksquare"), for: .normal)
        btnfemale.setImage(UIImage.init(named: "checksquare"), for: .selected)
//        malebtn.isSelected = true
    }

    @IBAction func selectgender(_ sender: UIButton) {
        if sender == malebtn {
            malebtn.isSelected = true
            btnfemale.isSelected = false
            malelbl.textColor = .red
            malelbl.backgroundColor = .green
            malebtn.backgroundColor = UIColor.yellow
        }
        else{
            malebtn.isSelected = false
            btnfemale.isSelected = true
            lblfemale.textColor = .purple
            lblfemale.backgroundColor = .green
        }
    }
    
}

